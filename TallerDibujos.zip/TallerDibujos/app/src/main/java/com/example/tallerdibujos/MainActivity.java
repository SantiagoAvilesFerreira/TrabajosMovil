package com.example.tallerdibujos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Método para abrir el primer enlace
    public void openLink1(View view) {
        openUrl("https://es.wikipedia.org/wiki/Tenis");
    }

    // Método para abrir el segundo enlace
    public void openLink2(View view) {
        openUrl("https://es.wikipedia.org/wiki/Ciclismo");
    }

    // Método para abrir el tercer enlace
    public void openLink3(View view) {
        openUrl("https://es.wikipedia.org/wiki/F%C3%BAtbol_Club_Barcelona");
    }

    // Método para abrir un enlace en el navegador
    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}